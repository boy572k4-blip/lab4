#!/usr/bin/env python3
"""
Grading script for steg_network-covert lab.
Called by Labtainer instructor after extracting student artifacts.
Args: student_dir lab_name
"""
import os
import sys

def check_file_contains(student_dir, container, rel_path, keyword):
    """Kiểm tra file tồn tại và chứa keyword (case-insensitive)"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path  = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            try:
                content = open(path).read()
                return keyword.lower() in content.lower()
            except Exception:
                pass
    return False

def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    results = {}

    # A1 – Ghi pattern IP ID bình thường
    results['ipid_pattern_normal'] = check_file_contains(
        student_dir, 'steg_network-covert.sender.student',
        'covert_lab/ipid_pattern_normal.txt', 'pattern')

    # A2 – Ghi pattern IP ID covert
    results['ipid_pattern_covert'] = check_file_contains(
        student_dir, 'steg_network-covert.sender.student',
        'covert_lab/ipid_pattern_covert.txt', 'pattern')

    # A3 – Nhận thông điệp qua IP ID
    results['result_ipid'] = check_file_contains(
        student_dir, 'steg_network-covert.receiver.student',
        'covert_lab/received_ipid.txt', 'COVERT')

    # B1 – Nhận thông điệp qua TCP ISN
    results['received_isn'] = check_file_contains(
        student_dir, 'steg_network-covert.receiver.student',
        'covert_lab/received_isn.txt', 'ISN')

    # B2 – Tính toán bandwidth
    results['bandwidth_result'] = check_file_contains(
        student_dir, 'steg_network-covert.sender.student',
        'covert_lab/bandwidth_result.txt', 'ipid_bps')

    # B3 – IDS phân tích
    results['ids_result'] = check_file_contains(
        student_dir, 'steg_network-covert.monitor.student',
        'covert_lab/ids_result.txt', 'ids_detected')

    labels = {
        'ipid_pattern_normal':  'A1 - Ghi pattern IP ID binh thuong',
        'ipid_pattern_covert':  'A2 - Ghi pattern IP ID covert',
        'result_ipid':          'A3 - Nhan thong diep qua IP ID',
        'received_isn':         'B1 - Nhan thong diep qua TCP ISN',
        'bandwidth_result':     'B2 - Tinh toan bandwidth',
        'ids_result':           'B3 - IDS phat hien covert channel',
    }

    for key, label in labels.items():
        mark = 'Y' if results[key] else 'N'
        print(f' {mark} -  {label}')

if __name__ == '__main__':
    main()
