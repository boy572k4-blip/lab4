#!/bin/bash
service ssh start 2>/dev/null

mkdir -p /var/labtainer
echo "steg_network-covert_seed" > /var/labtainer/seed

mkdir -p /home/ubuntu/.local
echo "steg_network-covert_seed" > /home/ubuntu/.local/.seed
echo "student@labtainer.local" > /home/ubuntu/.local/.email
echo "steg_network-covert" > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

touch /var/labtainer/did_param

mkdir -p /home/ubuntu/covert_lab
chown -R ubuntu:ubuntu /home/ubuntu/covert_lab

tail -f /dev/null
