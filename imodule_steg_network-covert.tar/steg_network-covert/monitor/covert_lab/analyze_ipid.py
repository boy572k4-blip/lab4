#!/usr/bin/env python3
"""
analyze_ipid.py - Phân tích pattern của các giá trị IP ID trong file pcap.
(Chạy trên máy monitor)
"""
import argparse
import sys
import os

try:
    from scapy.all import rdpcap, IP, conf
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài.")
    sys.exit(1)

def analyze_pcap(pcap_file, output_file=None):
    if not os.path.isfile(pcap_file):
        print(f"[ERROR] File không tồn tại: {pcap_file}")
        sys.exit(1)

    pkts = rdpcap(pcap_file)
    ip_ids = []
    for pkt in pkts:
        if IP in pkt:
            ip_ids.append(pkt[IP].id)

    if not ip_ids:
        print("[WARNING] Không tìm thấy IP packet nào!")
        return

    print(f"\n[ANALYZE] File: {pcap_file}")
    print(f"[INFO] Tổng số IP packets: {len(ip_ids)}")
    print(f"[INFO] 10 giá trị IP ID đầu tiên: {ip_ids[:10]}")
    print(f"[INFO] Min ID: {min(ip_ids)} | Max ID: {max(ip_ids)}")
    print(f"[INFO] Unique ID values: {len(set(ip_ids))}")

    diffs = [ip_ids[i+1] - ip_ids[i] for i in range(len(ip_ids)-1)]
    sequential_count = sum(1 for d in diffs if d == 1)
    ratio_seq = sequential_count / max(len(diffs), 1)

    if ratio_seq > 0.7:
        pattern = "sequential"
        print("[PATTERN] => SEQUENTIAL (tăng tuần tự từng 1)")
    elif len(set(ip_ids)) < len(ip_ids) * 0.3:
        pattern = "fixed"
        print("[PATTERN] => FIXED (nhiều giá trị lặp lại)")
    else:
        pattern = "random"
        print("[PATTERN] => RANDOM / COVERT (phân tán, không tuần tự)")

    lines = [
        f"total_packets={len(ip_ids)}",
        f"unique_ids={len(set(ip_ids))}",
        f"min_id={min(ip_ids)}",
        f"max_id={max(ip_ids)}",
        f"first_10={ip_ids[:10]}",
        f"pattern={pattern}",
    ]
    result = "\n".join(lines)
    print("\n[OUTPUT]"); print(result)

    if output_file:
        os.makedirs(os.path.dirname(os.path.abspath(output_file)), exist_ok=True)
        with open(output_file, 'w') as f:
            f.write(result + "\n")
        print(f"\n[OK] Lưu tại: {output_file}")

def main():
    parser = argparse.ArgumentParser(description='Analyze IP ID patterns (monitor)')
    parser.add_argument('--pcap',   required=True)
    parser.add_argument('--output', default=None)
    args = parser.parse_args()
    analyze_pcap(args.pcap, args.output)

if __name__ == '__main__':
    main()
