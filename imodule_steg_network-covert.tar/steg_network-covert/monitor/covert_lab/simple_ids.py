#!/usr/bin/env python3
"""
simple_ids.py - IDS đơn giản phát hiện covert channel trong IP ID.
Dựa trên phân tích entropy và tính tuần tự của IP ID values.
Threshold: nếu ratio ngẫu nhiên > threshold -> alert covert channel.
"""
import argparse
import sys
import os
import math
from collections import Counter

try:
    from scapy.all import rdpcap, IP, ICMP, conf
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài.")
    sys.exit(1)

def shannon_entropy(values):
    if not values:
        return 0.0
    counts = Counter(values)
    total = len(values)
    entropy = 0.0
    for c in counts.values():
        p = c / total
        entropy -= p * math.log2(p)
    return entropy

def run_ids(pcap_file, threshold, output_file=None):
    if not os.path.isfile(pcap_file):
        print(f"[ERROR] File không tồn tại: {pcap_file}")
        sys.exit(1)

    pkts = rdpcap(pcap_file)
    ip_ids = []
    for pkt in pkts:
        if IP in pkt and ICMP in pkt:
            ip_ids.append(pkt[IP].id)

    if not ip_ids:
        print("[WARNING] Không có ICMP packet nào để phân tích!")
        return

    print("=" * 55)
    print("  SIMPLE NETWORK IDS - COVERT CHANNEL DETECTION")
    print("=" * 55)
    print(f"[INFO] Phân tích {len(ip_ids)} ICMP packets")
    print(f"[INFO] Threshold: {threshold}")

    # Tính entropy (normalized)
    max_entropy = math.log2(len(ip_ids)) if len(ip_ids) > 1 else 1
    entropy = shannon_entropy(ip_ids)
    norm_entropy = entropy / max_entropy if max_entropy > 0 else 0

    # Kiểm tra tính tuần tự
    diffs = [ip_ids[i+1] - ip_ids[i] for i in range(len(ip_ids)-1)]
    sequential_ratio = sum(1 for d in diffs if d == 1) / max(len(diffs), 1)
    random_ratio = 1 - sequential_ratio

    print(f"\n[METRIC] Shannon Entropy (normalized): {norm_entropy:.4f}")
    print(f"[METRIC] Sequential IP ID ratio       : {sequential_ratio:.4f}")
    print(f"[METRIC] Random/Anomalous ratio        : {random_ratio:.4f}")

    alert_count = 0
    detected = "no"

    # Rule 1: Entropy thấp bất thường hoặc cao bất thường
    if norm_entropy > threshold or random_ratio > threshold:
        alert_count += 1
        detected = "yes"
        print(f"\n[ALERT #{alert_count}] IP ID pattern bất thường!")
        print(f"  -> Entropy={norm_entropy:.3f}, Random ratio={random_ratio:.3f}")
        print(f"  -> Vượt ngưỡng threshold={threshold}")
        print(f"  -> Nghi ngờ: COVERT CHANNEL qua IP ID field!")

    # Rule 2: Kiểm tra giá trị ASCII in được
    ascii_printable = sum(1 for v in ip_ids
                          if 32 <= (v >> 8) <= 126 and 32 <= (v & 0xFF) <= 126)
    ascii_ratio = ascii_printable / max(len(ip_ids), 1)
    if ascii_ratio > 0.5:
        alert_count += 1
        detected = "yes"
        print(f"\n[ALERT #{alert_count}] IP ID chứa ASCII printable data!")
        print(f"  -> ASCII printable ratio={ascii_ratio:.3f} > 0.5")
        print(f"  -> Nghi ngờ: dữ liệu text được giấu trong IP ID!")

    if detected == "no":
        print(f"\n[OK] Không phát hiện bất thường. Traffic có vẻ bình thường.")

    print("\n" + "=" * 55)

    lines = [
        f"ids_detected={detected}",
        f"alert_count={alert_count}",
        f"norm_entropy={norm_entropy:.4f}",
        f"sequential_ratio={sequential_ratio:.4f}",
        f"random_ratio={random_ratio:.4f}",
        f"ascii_ratio={ascii_ratio:.4f}",
        f"threshold={threshold}",
        f"total_packets={len(ip_ids)}",
    ]
    result = "\n".join(lines)

    if output_file:
        os.makedirs(os.path.dirname(os.path.abspath(output_file)), exist_ok=True)
        with open(output_file, 'w') as f:
            f.write(result + "\n")
        print(f"[OK] Lưu tại: {output_file}")

def main():
    parser = argparse.ArgumentParser(description='Simple IDS for Covert Channel Detection')
    parser.add_argument('--pcap',      required=True)
    parser.add_argument('--threshold', type=float, default=0.7)
    parser.add_argument('--output',    default=None)
    args = parser.parse_args()
    run_ids(args.pcap, args.threshold, args.output)

if __name__ == '__main__':
    main()
