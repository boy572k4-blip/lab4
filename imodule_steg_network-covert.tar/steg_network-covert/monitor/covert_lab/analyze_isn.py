#!/usr/bin/env python3
"""
analyze_isn.py - Phân tích phân phối TCP ISN trong pcap.
ISN bình thường: pseudo-random theo RFC 6528.
ISN covert: có pattern có thể decode thành ASCII.
"""
import argparse
import sys
import os
import struct

try:
    from scapy.all import rdpcap, IP, TCP, conf
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài.")
    sys.exit(1)

def analyze_isn(pcap_file, output_file=None):
    if not os.path.isfile(pcap_file):
        print(f"[ERROR] File không tồn tại: {pcap_file}")
        sys.exit(1)

    pkts = rdpcap(pcap_file)
    seqs = []
    for pkt in pkts:
        if IP in pkt and TCP in pkt:
            if pkt[TCP].flags & 0x02:  # SYN
                seqs.append(pkt[TCP].seq)

    if not seqs:
        print("[WARNING] Không tìm thấy TCP SYN packet nào!")
        return

    print(f"\n[ANALYZE TCP ISN] File: {pcap_file}")
    print(f"[INFO] Tổng SYN packets: {len(seqs)}")
    print(f"[INFO] 5 ISN đầu tiên (hex): {[hex(s) for s in seqs[:5]]}")

    # Kiểm tra xem có nhiều byte ASCII hợp lệ không
    ascii_count = 0
    for seq in seqs:
        b = struct.pack('>I', seq)
        for byte in b:
            if 32 <= byte <= 126:
                ascii_count += 1
    total_bytes = len(seqs) * 4
    ascii_ratio = ascii_count / max(total_bytes, 1)

    print(f"\n[ENTROPY] ASCII printable ratio: {ascii_ratio:.3f}")

    if ascii_ratio > 0.6:
        verdict = "COVERT_DETECTED - ISN chứa ASCII data bất thường!"
        print(f"[ALERT] {verdict}")
    else:
        verdict = "NORMAL - ISN phân phối ngẫu nhiên bình thường"
        print(f"[OK] {verdict}")

    lines = [
        f"total_syn_packets={len(seqs)}",
        f"ascii_printable_ratio={ascii_ratio:.4f}",
        f"first_5_seqs={[hex(s) for s in seqs[:5]]}",
        f"verdict={verdict}",
    ]
    result = "\n".join(lines)
    print("\n[OUTPUT]")
    print(result)

    if output_file:
        os.makedirs(os.path.dirname(os.path.abspath(output_file)), exist_ok=True)
        with open(output_file, 'w') as f:
            f.write(result + "\n")
        print(f"\n[OK] Lưu tại: {output_file}")

def main():
    parser = argparse.ArgumentParser(description='Analyze TCP ISN')
    parser.add_argument('--pcap',   required=True)
    parser.add_argument('--output', default=None)
    args = parser.parse_args()
    analyze_isn(args.pcap, args.output)

if __name__ == '__main__':
    main()
