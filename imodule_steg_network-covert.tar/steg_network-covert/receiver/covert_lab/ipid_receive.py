#!/usr/bin/env python3
"""
ipid_receive.py - Nhận và giải mã dữ liệu ẩn từ trường IP ID.
Lắng nghe ICMP packet, đọc IP ID field, ghép lại thông điệp.
"""
import argparse
import sys
import os
import struct
import signal

try:
    from scapy.all import sniff, IP, ICMP, conf
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài.")
    sys.exit(1)

received_ids = []
done = False

def handle_packet(pkt):
    global done
    if IP in pkt and ICMP in pkt:
        ip_id = pkt[IP].id
        if ip_id == 0xFFFF:
            print("\n[INFO] Nhận terminator packet (IP ID=0xFFFF) -> Kết thúc")
            done = True
            return True  # stop sniff
        received_ids.append(ip_id)
        print(f"  [RECV] IP ID = {ip_id:#06x} ({ip_id})")

def decode_ids(id_list):
    chars = []
    for ip_id in id_list:
        high = (ip_id >> 8) & 0xFF
        low  = ip_id & 0xFF
        if high != 0 and 32 <= high <= 126:
            chars.append(chr(high))
        if low != 0 and 32 <= low <= 126:
            chars.append(chr(low))
    return ''.join(chars)

def main():
    parser = argparse.ArgumentParser(description='IP ID Covert Channel Receiver')
    parser.add_argument('--iface',  default='eth0')
    parser.add_argument('--output', default=None)
    parser.add_argument('--timeout', type=int, default=60)
    args = parser.parse_args()

    print(f"[INFO] Lắng nghe trên {args.iface} (timeout={args.timeout}s)...")
    print(f"[INFO] Đang chờ ICMP packets có chứa covert data...")

    sniff(iface=args.iface, filter="icmp", prn=handle_packet,
          stop_filter=lambda p: done, timeout=args.timeout)

    message = decode_ids(received_ids)
    print(f"\n[RESULT] Thông điệp giải mã: '{message}'")
    print(f"[INFO] Tổng packets nhận: {len(received_ids)}")

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, 'w') as f:
            f.write(f"COVERT_CHANNEL_IP_ID\n")
            f.write(f"message={message}\n")
            f.write(f"packets_received={len(received_ids)}\n")
            f.write(f"raw_ids={received_ids}\n")
        print(f"[OK] Lưu tại: {args.output}")

if __name__ == '__main__':
    main()
