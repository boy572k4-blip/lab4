#!/usr/bin/env python3
"""
isn_receive.py - Nhận và giải mã dữ liệu ẩn từ trường TCP ISN.
Lắng nghe TCP SYN packet, đọc seq number, ghép thông điệp.
"""
import argparse
import sys
import os
import struct

try:
    from scapy.all import sniff, IP, TCP, conf
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài.")
    sys.exit(1)

received_seqs = []
done = False

def handle_packet(pkt):
    global done
    if IP in pkt and TCP in pkt:
        tcp = pkt[TCP]
        if tcp.flags & 0x02:  # SYN flag
            seq = tcp.seq
            if seq == 0xDEADBEEF:
                print("\n[INFO] Nhận terminator (seq=0xDEADBEEF) -> Kết thúc")
                done = True
                return True
            received_seqs.append(seq)
            print(f"  [RECV] TCP ISN = {seq:#010x} ({seq})")

def decode_seqs(seq_list):
    chars = []
    for seq in seq_list:
        b = struct.pack('>I', seq)
        for byte in b:
            if 32 <= byte <= 126:
                chars.append(chr(byte))
    return ''.join(chars).rstrip('\x00')

def main():
    parser = argparse.ArgumentParser(description='TCP ISN Covert Channel Receiver')
    parser.add_argument('--port',    type=int, default=8080)
    parser.add_argument('--output',  default=None)
    parser.add_argument('--timeout', type=int, default=60)
    args = parser.parse_args()

    filt = f"tcp and dst port {args.port} and tcp[tcpflags] & tcp-syn != 0"
    print(f"[INFO] Lắng nghe TCP SYN tại port {args.port} (timeout={args.timeout}s)...")
    print(f"[INFO] Filter: {filt}")

    sniff(filter=filt, prn=handle_packet,
          stop_filter=lambda p: done, timeout=args.timeout)

    message = decode_seqs(received_seqs)
    print(f"\n[RESULT] Thông điệp giải mã từ ISN: '{message}'")
    print(f"[INFO] Tổng SYN packets nhận: {len(received_seqs)}")

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, 'w') as f:
            f.write(f"COVERT_CHANNEL_TCP_ISN\n")
            f.write(f"ISN_message={message}\n")
            f.write(f"packets_received={len(received_seqs)}\n")
            f.write(f"raw_seqs={[hex(s) for s in received_seqs]}\n")
        print(f"[OK] Lưu tại: {args.output}")

if __name__ == '__main__':
    main()
