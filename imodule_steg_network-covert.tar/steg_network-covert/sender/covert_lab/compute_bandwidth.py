#!/usr/bin/env python3
"""
compute_bandwidth.py - Tính toán băng thông của covert channel.
IP ID  channel: 16 bits/packet
TCP ISN channel: 32 bits/packet
"""
import argparse
import os

def compute(bits_ipid, bits_isn, pps, output_file=None):
    ipid_bps = bits_ipid * pps
    isn_bps  = bits_isn  * pps

    ipid_Bps = ipid_bps / 8
    isn_Bps  = isn_bps  / 8

    print("=" * 50)
    print("  COVERT CHANNEL BANDWIDTH ANALYSIS")
    print("=" * 50)
    print(f"  Packets per second (pps) : {pps}")
    print()
    print(f"  [IP ID Channel]")
    print(f"    Bits per packet  : {bits_ipid} bits")
    print(f"    Bandwidth        : {ipid_bps} bps  ({ipid_Bps:.1f} bytes/s)")
    print()
    print(f"  [TCP ISN Channel]")
    print(f"    Bits per packet  : {bits_isn} bits")
    print(f"    Bandwidth        : {isn_bps} bps  ({isn_Bps:.1f} bytes/s)")
    print()
    print(f"  ISN channel là {bits_isn//bits_ipid}x mạnh hơn IP ID channel")
    print("=" * 50)

    lines = [
        f"pps={pps}",
        f"ipid_bits_per_packet={bits_ipid}",
        f"isn_bits_per_packet={bits_isn}",
        f"ipid_bps={ipid_bps}",
        f"isn_bps={isn_bps}",
        f"ipid_bytes_per_sec={ipid_Bps:.1f}",
        f"isn_bytes_per_sec={isn_Bps:.1f}",
    ]

    result = "\n".join(lines)

    if output_file:
        os.makedirs(os.path.dirname(os.path.abspath(output_file)), exist_ok=True)
        with open(output_file, 'w') as f:
            f.write(result + "\n")
        print(f"\n[OK] Lưu tại: {output_file}")

    return ipid_bps, isn_bps

def main():
    parser = argparse.ArgumentParser(description='Compute Covert Channel Bandwidth')
    parser.add_argument('--bits-per-packet-ipid', type=int, default=16)
    parser.add_argument('--bits-per-packet-isn',  type=int, default=32)
    parser.add_argument('--packets-per-second',   type=int, default=10)
    parser.add_argument('--output', default=None)
    args = parser.parse_args()
    compute(args.bits_per_packet_ipid, args.bits_per_packet_isn,
            args.packets_per_second, args.output)

if __name__ == '__main__':
    main()
