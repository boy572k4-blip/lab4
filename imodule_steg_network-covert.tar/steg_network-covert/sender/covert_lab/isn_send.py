#!/usr/bin/env python3
"""
isn_send.py - Gửi dữ liệu ẩn qua trường TCP Initial Sequence Number (32-bit)
Mỗi SYN packet mang 4 bytes dữ liệu ẩn trong trường ISN.
"""
import argparse
import sys
import time
import struct

try:
    from scapy.all import IP, TCP, send, conf, RandShort
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài.")
    sys.exit(1)

def text_to_bytes(text):
    return list(text.encode('ascii'))

def send_covert_isn(dest, port, message, count, delay=0.1):
    data = text_to_bytes(message)
    # Padding thành bội số của 4 bytes
    while len(data) % 4 != 0:
        data.append(0)

    packets_needed = len(data) // 4  # 4 bytes per packet

    print(f"[INFO] Gửi covert channel qua TCP ISN tới {dest}:{port}")
    print(f"[INFO] Thông điệp: '{message}' ({len(text_to_bytes(message))} bytes)")
    print(f"[INFO] Sau padding: {len(data)} bytes -> {packets_needed} packets")
    print(f"[INFO] Bắt đầu gửi SYN packets...")

    sent = 0
    for i in range(min(count, packets_needed)):
        b0, b1, b2, b3 = data[4*i], data[4*i+1], data[4*i+2], data[4*i+3]
        isn = struct.unpack('>I', bytes([b0, b1, b2, b3]))[0]

        sport = int(RandShort())
        pkt = IP(dst=dest) / TCP(dport=port, sport=sport, flags='S', seq=isn)
        send(pkt)
        sent += 1
        time.sleep(delay)
        if (i+1) % 10 == 0:
            print(f"  [SEND] {i+1}/{min(count,packets_needed)} SYN packets, ISN={isn}")

    # Terminator: ISN = 0xDEADBEEF
    term = IP(dst=dest) / TCP(dport=port, sport=int(RandShort()), flags='S', seq=0xDEADBEEF)
    send(term)

    print(f"[SUCCESS] Đã gửi {sent} data packets + 1 terminator (ISN=0xDEADBEEF)")
    print(f"[DONE] Covert channel TCP ISN hoàn thành")

def main():
    parser = argparse.ArgumentParser(description='TCP ISN Covert Channel Sender')
    parser.add_argument('--dest',    required=True)
    parser.add_argument('--port',    type=int, default=8080)
    parser.add_argument('--message', required=True)
    parser.add_argument('--count',   type=int, default=64)
    parser.add_argument('--delay',   type=float, default=0.1)
    args = parser.parse_args()
    send_covert_isn(args.dest, args.port, args.message, args.count, args.delay)

if __name__ == '__main__':
    main()
