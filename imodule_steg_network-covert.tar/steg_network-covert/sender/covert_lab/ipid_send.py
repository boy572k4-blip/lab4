#!/usr/bin/env python3
"""
ipid_send.py - Gửi dữ liệu ẩn qua trường IP Identification (16-bit)
Sử dụng thư viện scapy để tạo packet với IP ID tùy chỉnh.
Mỗi packet mang 2 bytes (16 bits) dữ liệu.
"""
import argparse
import sys
import time

try:
    from scapy.all import IP, ICMP, send, conf
    conf.verb = 0
except ImportError:
    print("[ERROR] Scapy chưa được cài. Chạy: pip3 install scapy")
    sys.exit(1)

def text_to_bytes(text):
    return list(text.encode('ascii'))

def send_covert_ipid(dest, message, count, delay=0.1):
    data = text_to_bytes(message)
    # Pad hoặc cắt để vừa với count packets (mỗi packet 2 bytes)
    # Đóng gói: byte1 = high byte IP ID, byte2 = low byte IP ID
    packets_needed = (len(data) + 1) // 2  # 2 bytes per packet
    
    print(f"[INFO] Gửi covert channel qua IP ID tới {dest}")
    print(f"[INFO] Thông điệp: '{message}' ({len(data)} bytes)")
    print(f"[INFO] Số packet cần: {packets_needed}, count={count}")
    print(f"[INFO] Bắt đầu gửi...")

    sent = 0
    for i in range(min(count, packets_needed)):
        high = data[2*i] if 2*i < len(data) else 0
        low  = data[2*i+1] if 2*i+1 < len(data) else 0
        ip_id = (high << 8) | low

        pkt = IP(dst=dest, id=ip_id) / ICMP()
        send(pkt)
        sent += 1
        time.sleep(delay)
        if (i+1) % 10 == 0:
            print(f"  [SEND] {i+1}/{min(count,packets_needed)} packets")

    # Gửi thêm terminator packet (IP ID = 0xFFFF)
    term = IP(dst=dest, id=0xFFFF) / ICMP()
    send(term)

    print(f"[SUCCESS] Đã gửi {sent} data packets + 1 terminator")
    print(f"[DONE] Covert channel IP ID hoàn thành")

def main():
    parser = argparse.ArgumentParser(description='IP ID Covert Channel Sender')
    parser.add_argument('--dest',    required=True,  help='Địa chỉ IP đích')
    parser.add_argument('--message', required=True,  help='Thông điệp cần giấu')
    parser.add_argument('--count',   type=int, default=80, help='Số packets tối đa')
    parser.add_argument('--delay',   type=float, default=0.1, help='Delay giữa các packet (giây)')
    args = parser.parse_args()
    send_covert_ipid(args.dest, args.message, args.count, args.delay)

if __name__ == '__main__':
    main()
